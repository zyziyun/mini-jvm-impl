#pragma once

int hb_read_source_file(java_class_t * cls);
struct java_class * hb_load_class (const char * path);
