import java.lang.Runtime;

public class TestExit {
	public static void main (String[] args) {
		Runtime r = Runtime.getRuntime();
		r.exit(0);
	}
}
