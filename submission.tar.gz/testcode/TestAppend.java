public class TestAppend {

	
	public static void main (String[] args) {
		String x = "a" + "b" + "c" + "d";

		System.out.println(x);

		x = "a" + 1;

		System.out.println(x);

			
		
	}
}
