package java.lang;

public class Error extends Throwable
{
}




