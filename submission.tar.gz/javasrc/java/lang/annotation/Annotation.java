package java.lang.annotation;

public interface Annotation
{
    boolean equals(Object obj);
    
    int hashCode();
    
    String toString();
}
