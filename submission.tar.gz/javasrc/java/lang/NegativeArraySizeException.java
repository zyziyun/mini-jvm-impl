package java.lang;

public class NegativeArraySizeException extends RuntimeException
{
	public NegativeArraySizeException()
	{
		super();
	}

	public NegativeArraySizeException(String message)
	{
		super(message);
	}
}
