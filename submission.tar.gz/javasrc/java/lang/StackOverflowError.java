package java.lang;

public class StackOverflowError extends Error
{
}
