package java.io;

public interface Flushable {
	void flush() throws IOException;
}
